// Copyright 2015 Golang-China. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//
// Go圣经中文版.
//
// 项目主页: https://github.com/golang-china/gopl-zh
//
// 原版官网: http://gopl.io
//
package gopl_zh
